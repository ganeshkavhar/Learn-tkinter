import tkinter
from tkinter import messagebox


root = tkinter.Tk()
root.withdraw()

messagebox.showerror("Fatal Error", "Something went badly wrong :(")
